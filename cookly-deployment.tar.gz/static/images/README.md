# Recipe Capture PWA Icons
# These are placeholder files - replace with actual icon files
# Recommended sizes: 72x72, 96x96, 128x128, 144x144, 152x152, 192x192, 384x384, 512x512
# Format: PNG with transparent background
# Theme: Dark background with cyber-green accents, cooking/food related

For now, these placeholder files exist to prevent 404 errors.
Create actual icon files with the recipe/cooking theme matching the app's cyber-green aesthetic.